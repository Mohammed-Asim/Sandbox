import Supportpage from "./support";
export default Supportpage;