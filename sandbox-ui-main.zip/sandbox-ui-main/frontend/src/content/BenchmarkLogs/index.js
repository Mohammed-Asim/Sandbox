import BenchmarkPage from "./benchmark";
export default BenchmarkPage;