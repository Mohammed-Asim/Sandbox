import ConfigurationPage from "./configuration";
export default ConfigurationPage;