import React from 'react';

const CommonUIContext = React.createContext();

export default CommonUIContext;