#!/bin/bash

docker build . -f Dockerfile -t sandbox-api
